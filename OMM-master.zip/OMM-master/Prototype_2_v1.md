# OMM Micro digestor: Prototype 2

## Context

After the experience of [the prototyping of the first version](https://github.com/LPS-MYNE/OMM/blob/master/Prototype_1_v1.md) of the micro digestor for biogas production from biowaste in Mouans-Sartoux during the [OSCE Days](http://community.oscedays.org/c/local-teams/mouanssartoux), the OMM Team was willing to set another prototype located on site at La M[Y]NE in order to run more easily tests and experiments. Indeed, the first prototype has been left on site in Mouans-Sartoux for local experiment, given that the sizing has been worked out from local needs and constraints. 
